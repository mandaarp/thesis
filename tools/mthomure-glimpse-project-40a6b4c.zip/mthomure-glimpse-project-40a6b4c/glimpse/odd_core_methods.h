#include "../glimpse/core/array.h"

void UpdateCovariance(ArrayRef4D<float>& cov, ArrayRef3D<float>& idata, 
    ArrayRef1D<float>& means, int step);

